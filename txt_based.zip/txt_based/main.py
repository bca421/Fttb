# main.py
from game_intro import game_intro
from player_setup import player_setup
from locations import locations
from events import random_event

def describe_location(location):
    print(f"You are at the {location.capitalize()}.")
    print(locations[location]["description"])

def discover_secret_path(location, player):
    if "secret" in locations[location]:
        print(locations[location]["secret"])
        choice = input("Do you want to explore the secret path? (yes/no) > ")
        if choice.lower() == "yes":
            return locations[location]["secret_location"]
    return location

def game_loop(player):
    current_location = "village"
    while True:
        print("\nWhat do you want to do?")
        print("1. Explore the forest")
        print("2. Visit the village")
        print("3. Enter the cave")
        print("4. Explore the castle")
        print("5. Go to the lake")
        print("6. Check inventory")
        print("7. Quit")

        choice = input("> ")

        if choice == "1":
            current_location = "forest"
        elif choice == "2":
            current_location = "village"
        elif choice == "3":
            current_location = "cave"
        elif choice == "4":
            current_location = "castle"
        elif choice == "5":
            current_location = "lake"
        elif choice == "6":
            print(f"Inventory: {player['inventory']}")
            print(f"Health: {player['health']}")
            continue
        elif choice == "7":
            print("Thanks for playing!")
            break
        else:
            print("Invalid choice. Try again.")
            continue

        describe_location(current_location)
        current_location = discover_secret_path(current_location, player)
        random_event(current_location, player)

        if player["health"] <= 0:
            print("You have died. Game over.")
            break

# Start the game
game_intro()
player = player_setup()
game_loop(player)
