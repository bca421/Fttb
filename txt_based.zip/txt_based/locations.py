# locations.py
locations = {
    "forest": {
        "description": "A dark and spooky forest with towering trees whose branches intertwine to form a canopy, blocking most of the sunlight. The air is thick with the smell of pine and moss.",
        "secret": "You notice a hidden path, barely visible, leading deeper into the forest. It's covered with thick vines and overgrown bushes.",
        "secret_location": "hidden_grove"
    },
    "village": {
        "description": "A small, peaceful village nestled in a valley. The cobblestone streets are lined with quaint houses, and the sound of children playing fills the air. The villagers glance at you curiously, whispering about the arrival of a new hero.",
        "secret": "You hear whispers among the villagers about an old well. They say it hides a secret passage that only the brave dare to explore.",
        "secret_location": "underground_tunnel"
    },
    "cave": {
        "description": "A deep, dark cave whose entrance is almost hidden behind a waterfall. The sound of water echoes through the cavern, and the air is cool and damp. Shadows dance on the walls, creating an eerie atmosphere.",
        "secret": "You see a faint light coming from behind a rock wall, indicating there might be a hidden chamber beyond.",
        "secret_location": "hidden_chamber"
    },
    "castle": {
        "description": "An ancient castle, now in ruins, stands atop a hill. Its once-grand halls are now overrun with ivy, and the wind whistles through the broken windows. The castle holds many secrets, and perhaps some treasures.",
        "secret": "You find a loose brick in one of the walls, revealing a hidden staircase that spirals down into darkness.",
        "secret_location": "secret_library"
    },
    "lake": {
        "description": "A serene lake surrounded by lush greenery. The water is crystal clear, reflecting the blue sky above. Birds chirp melodiously from the trees. The lake seems peaceful, yet something feels mysterious.",
        "secret": "You notice a small boat hidden among the reeds, just big enough for one person to row across the lake.",
        "secret_location": "island"
    },
    "hidden_grove": {
        "description": "A hidden grove filled with rare plants and flowers. The sunlight filters through the leaves, casting a magical glow on the ground. The air is filled with the fragrance of blooming flowers.",
        "secret": "You find a cave entrance covered by thick vines, almost invisible to the untrained eye.",
        "secret_location": "cave"
    },
    "underground_tunnel": {
        "description": "An underground tunnel that seems to go on forever. The walls are damp, and the air is musty. Faint light filters in from cracks in the ceiling, creating an eerie ambiance.",
        "secret": "You see a faint light at the end of the tunnel, hinting at an exit or another hidden area.",
        "secret_location": "village"
    },
    "hidden_chamber": {
        "description": "A hidden chamber filled with ancient artifacts and dusty tomes. The air is thick with the smell of old paper and history. The artifacts seem to tell stories of a long-lost civilization.",
        "secret": "You notice a ladder leading upwards, possibly to a room above.",
        "secret_location": "castle"
    },
    "secret_library": {
        "description": "A secret library filled with old books and scrolls. The shelves are lined with knowledge lost to time, and a thick layer of dust covers everything. You can feel the wisdom of the ages in this room.",
        "secret": "You find a hidden door behind a bookshelf, leading to another secret area.",
        "secret_location": "castle"
    },
    "island": {
        "description": "A small island in the middle of the lake. The island is lush with vegetation and seems almost untouched by humans. You feel a sense of tranquility here.",
        "secret": "You find a hidden path leading to a treasure chest buried deep within the island.",
        "secret_location": "lake"
    }
}
